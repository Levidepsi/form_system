const Error = ({ children }) => {
	return <div className='text-danger'>{children}</div>;
};

export default Error;
